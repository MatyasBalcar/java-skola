public class TaxPayer {
    String name;
    int getIncomeTax(int income){
        return 0;
    }

    public String getInfo(){
        return "Name: " + name;
    }

    public TaxPayer(String name){
        this.name = name;
    }
}
